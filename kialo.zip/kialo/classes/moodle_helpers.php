<?php

namespace mod_kialo;

class moodle_helpers {

}
